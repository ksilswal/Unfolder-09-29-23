class origami:
    
    def __init__(origamiCoor,AdjacencyMatrix,Creases,layers):
            self.origamiCoor =  [[0,0], [1,0], [0,1], [1,1]]
            self.Adjacency = [[0,-1,1,0],[-1,0,0,-1],[1,0,0,1],[0,-1,1,0]]
            self.Creases = [[0,2,2,0], [0,0,0,4], [2,0,0,1], [0,4,1,0]]
            self.layers = [[0,4,2,0], [4,0,0,4], [2,0,0,1], [0,4,1,0]]